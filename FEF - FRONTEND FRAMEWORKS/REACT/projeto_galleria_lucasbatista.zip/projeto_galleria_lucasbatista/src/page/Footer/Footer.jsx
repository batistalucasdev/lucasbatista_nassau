function Footer() {
    return (
        <footer>
            <p><span>Galleria</span> &copy; 2021</p>
        </footer>
    )
}

export default Footer